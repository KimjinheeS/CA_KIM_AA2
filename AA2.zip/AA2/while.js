var x = 1

while(x < 52){
    if(x<51){
        document.write(x+ ", ");
        x++;
        x++;
    }else{
        document.write(x);
        x++;
        x++;
    }
}