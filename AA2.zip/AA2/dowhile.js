var y = 2

do{
    if(y<50){
        document.write(y+ ", ");
        y++;
        y++;
    }else{
        document.write(y);
        y++;
        y++;
    }
}while(y < 51);